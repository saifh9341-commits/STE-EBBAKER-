# Implementation Manifest

Architecture:
UI -> Application Services -> Domain Services -> Repositories -> SQLite.

Domains:
Core, authentication, roles/permissions, multi-company, accounting, customers/suppliers,
inventory, purchases/returns, sales/returns, cash/banks, expenses/revenues, partners,
reports, dashboard, backup/restore/audit, printing/export, testing/security and installer.

A module is considered production-complete only after its workflow is implemented, integrated,
tested and exercised on the target Windows build. Empty folders or placeholder buttons are not
treated as completed functionality.
