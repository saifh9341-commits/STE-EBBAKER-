# FinCore ERP Architecture

## 1. Architecture style

Layered modular architecture:

UI
 -> Application Services
 -> Domain/Accounting/Inventory Services
 -> Repositories
 -> SQLite

Cross-cutting services:
- Security
- Audit
- Backup/Recovery
- Configuration
- Logging
- Localization
- Printing/Export

The UI never writes SQL directly. Business services own transaction boundaries.

## 2. Technology decisions

### C++17
Chosen for native Windows desktop performance, deterministic resource management, and long-term maintainability.

### Qt 5.12.x Widgets
Chosen because it provides mature desktop controls, printing support, internationalization and RTL support while preserving the Windows 7 compatibility target. Qt's historical 5.12.12 configuration includes Windows 7 x86.

### SQLite
Chosen for offline-first deployment, low operational overhead, ACID transactions and excellent performance for a single-workstation/small-office accounting product. The schema is designed with indexes and pagination for large datasets.

### CMake
Provides reproducible builds and keeps the project portable across supported compilers.

## 3. Database policy

- One SQLite file per company.
- Foreign keys enabled on every connection.
- Every financial operation uses an explicit transaction.
- Journal entries must balance before commit.
- Posted accounting documents are immutable. Corrections use reversal/return documents.
- Closed financial years are protected by service-layer authorization and database constraints where practical.
- Monetary values are stored as integer minor units (e.g. millimes/cents), not floating point.
- Quantities support fixed decimal precision using scaled integers in the first production schema revision.

## 4. Data directories

Program installation:
C:\Program Files\FinCoreERP\

User/company data:
%PROGRAMDATA%\FinCoreERP\Companies\<company-id>\

Logs:
%PROGRAMDATA%\FinCoreERP\Logs\

Backups:
user-selected directory; default:
%PROGRAMDATA%\FinCoreERP\Backups\<company-id>\

The database is never stored under Program Files.

## 5. Security architecture

- Passwords: Argon2id in the security module, with per-password random salt.
- Session authorization: role + permission checks at service boundary.
- SQL: prepared statements only.
- Sensitive local secrets: Windows DPAPI where machine/user binding is appropriate.
- Backup encryption: authenticated encryption (AES-256-GCM) with a randomly generated data key protected separately.
- Audit log is append-oriented; ordinary users cannot edit it.
- No credentials are written to logs.

## 6. Accounting invariants

For every posted journal:
SUM(debit) == SUM(credit)

For every sales invoice:
- invoice total = lines + taxes - discounts + extra charges
- stock movement is created only for stock items
- receivable/cash/bank entries match the settlement
- the accounting journal is generated from the finalized document

A sales invoice is committed only if all of those operations succeed inside one transaction.

## 7. Backup strategy

Normal database:
SQLite WAL mode.

Backup procedure:
1. Pause new financial writes.
2. Checkpoint WAL.
3. Verify database integrity.
4. Create a consistent SQLite backup/copy.
5. Compute SHA-256 checksum.
6. Optionally encrypt the backup.
7. Write backup metadata.
8. Resume writes.

Restore:
1. Verify backup signature/checksum and version.
2. Close database connections.
3. Preserve current database as a safety copy.
4. Replace database atomically.
5. Run integrity check and schema migration.
6. Reopen database.
7. Record restore in audit log.

For network folders, backup is a file-transfer destination only; SQLite database files are not opened directly from network shares.

## 8. Scalability

- Composite indexes on company_id/date/document_number.
- Pagination in all large lists.
- Search fields indexed.
- Reports query database aggregates rather than loading all rows into RAM.
- Transactions are short and explicit.
- UI reads can run on a dedicated database connection where appropriate.

## 9. Future modules

Each module owns:
- domain models
- repository interfaces
- service layer
- UI pages/dialogs
- report queries
- tests

No module may bypass the accounting service for posted financial effects.
