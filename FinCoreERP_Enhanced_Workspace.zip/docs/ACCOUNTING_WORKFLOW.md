# Accounting Workflow

## Sales invoice

1. Validate customer, warehouse, lines, prices, tax and payment.
2. Start database transaction.
3. Create sales invoice header and lines.
4. Create stock OUT movements for stock items.
5. Calculate cost of goods sold.
6. Create customer receivable if credit remains.
7. Create cash/bank settlement entry for paid amount.
8. Generate balanced journal entry:
   - Dr Cash/Bank and/or Accounts Receivable
   - Cr Sales Revenue
   - Cr Output Tax
   - Dr Cost of Goods Sold
   - Cr Inventory
9. Write audit event.
10. Commit.

Any failure rolls back the complete operation.

## Purchase invoice

1. Validate supplier, warehouse, lines, taxes and payment.
2. Start transaction.
3. Create purchase invoice.
4. Create stock IN movements.
5. Create supplier payable for unpaid amount.
6. Create cash/bank settlement for paid amount.
7. Journal:
   - Dr Inventory / Expense
   - Dr Input Tax
   - Cr Cash/Bank and/or Accounts Payable
8. Audit.
9. Commit.

## Returns

Returns are separate documents and reverse the relevant stock and accounting effects. Posted source documents are not destructively edited.

## Payments/receipts

A receipt reduces a customer receivable or records other income.
A payment reduces a supplier payable or records an expense.

## Expenses

Expense transaction:
Dr Expense account
Cr Cash/Bank or Payable

## Partner contribution

Dr Cash/Bank
Cr Partner Capital

Partner withdrawal:
Dr Partner Current/Drawings
Cr Cash/Bank

## Period close

- Prevent ordinary posting into the closed period.
- Generate closing entries according to configured policy.
- Calculate retained earnings/opening balances.
- Keep all original transactions immutable.
