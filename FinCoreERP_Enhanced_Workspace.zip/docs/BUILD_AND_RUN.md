# FinCore ERP — Build / Run / Package

Target: Windows 7/8/8.1/10/11 with a frozen compatible Qt 5.12.x toolchain.

Build:
1. cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
2. cmake --build build --config Release
3. Run build\Release\FinCoreERP.exe

Company data is kept outside the installation directory. Uninstall must not delete it.

Release checks: tests, login/permissions, accounting balance, transaction rollback, backup/restore, reports, exports, printing and installer.
