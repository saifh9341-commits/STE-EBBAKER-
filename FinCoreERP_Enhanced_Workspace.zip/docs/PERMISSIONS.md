# Roles and Permissions

| Permission group | Administrator | Manager | Accountant | Cashier | Sales | Warehouse |
|---|---:|---:|---:|---:|---:|---:|
| Dashboard | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Company settings | ✓ | limited | - | - | - | - |
| Users/Roles | ✓ | limited | - | - | - | - |
| Customers | ✓ | ✓ | ✓ | read | ✓ | read |
| Suppliers | ✓ | ✓ | ✓ | read | - | read |
| Products | ✓ | ✓ | ✓ | read | ✓ | ✓ |
| Warehouses | ✓ | ✓ | ✓ | - | read | ✓ |
| Sales | ✓ | ✓ | ✓ | receipt | ✓ | read |
| Purchases | ✓ | ✓ | ✓ | - | - | ✓ |
| Cash/Bank | ✓ | ✓ | ✓ | ✓ | limited | - |
| Accounting | ✓ | ✓ | ✓ | - | - | - |
| Reports | ✓ | ✓ | ✓ | cash reports | sales reports | stock reports |
| Backup/Restore | ✓ | limited | - | - | - | - |
| Audit log | ✓ | ✓ | read | - | - | - |

The production implementation will store permissions as data, not hard-coded role names. Administrators can create additional roles.
