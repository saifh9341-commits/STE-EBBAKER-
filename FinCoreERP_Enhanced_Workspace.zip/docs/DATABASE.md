# Database model

Core tables:

- companies
- company_settings
- users
- roles
- permissions
- role_permissions
- user_roles
- audit_logs
- currencies
- tax_rates
- financial_years
- accounts
- journal_entries
- journal_entry_lines
- customers
- suppliers
- partners
- partner_transactions
- categories
- units
- products
- warehouses
- stock_movements
- price_lists
- product_prices
- sales_quotes
- sales_orders
- sales_invoices
- sales_invoice_lines
- sales_returns
- sales_return_lines
- purchase_quotes
- purchase_orders
- purchase_invoices
- purchase_invoice_lines
- purchase_returns
- purchase_return_lines
- payments
- receipts
- cash_accounts
- bank_accounts
- account_transfers
- expenses
- revenues
- attachments
- backups
- app_settings
- schema_migrations

All business tables carry company_id where data is company-scoped. Foreign keys and unique constraints prevent cross-company references.
