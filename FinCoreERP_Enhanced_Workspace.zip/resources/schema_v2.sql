CREATE TABLE IF NOT EXISTS document_sequences (
 company_id INTEGER NOT NULL, sequence_key TEXT NOT NULL, next_number INTEGER NOT NULL DEFAULT 1,
 PRIMARY KEY(company_id,sequence_key), FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS sales_returns (
 id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, customer_id INTEGER, warehouse_id INTEGER,
 financial_year_id INTEGER NOT NULL, return_no INTEGER NOT NULL, return_date TEXT NOT NULL,
 total_minor INTEGER NOT NULL DEFAULT 0, journal_entry_id INTEGER, created_by INTEGER NOT NULL,
 UNIQUE(company_id,financial_year_id,return_no),
 FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS purchase_returns (
 id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, supplier_id INTEGER, warehouse_id INTEGER,
 financial_year_id INTEGER NOT NULL, return_no INTEGER NOT NULL, return_date TEXT NOT NULL,
 total_minor INTEGER NOT NULL DEFAULT 0, journal_entry_id INTEGER, created_by INTEGER NOT NULL,
 UNIQUE(company_id,financial_year_id,return_no),
 FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS stock_transfers (
 id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, from_warehouse_id INTEGER NOT NULL,
 to_warehouse_id INTEGER NOT NULL, transfer_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'POSTED',
 created_by INTEGER NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS exchange_rates (
 id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, currency_id INTEGER NOT NULL,
 rate_date TEXT NOT NULL, rate_to_base REAL NOT NULL CHECK(rate_to_base>0),
 UNIQUE(company_id,currency_id,rate_date), FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_product_name ON products(company_id,name);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales_invoices(company_id,invoice_date);
CREATE INDEX IF NOT EXISTS idx_purchase_date ON purchase_invoices(company_id,invoice_date);
