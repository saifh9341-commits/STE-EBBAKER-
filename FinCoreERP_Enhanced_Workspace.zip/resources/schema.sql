PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS companies (
    id INTEGER PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    legal_name TEXT,
    tax_number TEXT,
    phone TEXT,
    email TEXT,
    address TEXT,
    logo_path TEXT,
    base_currency_id INTEGER,
    fiscal_year_start_month INTEGER NOT NULL DEFAULT 1 CHECK(fiscal_year_start_month BETWEEN 1 AND 12),
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_settings (
    company_id INTEGER PRIMARY KEY,
    invoice_prefix TEXT NOT NULL DEFAULT 'INV',
    purchase_prefix TEXT NOT NULL DEFAULT 'PUR',
    decimal_places INTEGER NOT NULL DEFAULT 3 CHECK(decimal_places BETWEEN 0 AND 6),
    tax_enabled INTEGER NOT NULL DEFAULT 0 CHECK(tax_enabled IN (0,1)),
    tax_inclusive INTEGER NOT NULL DEFAULT 0 CHECK(tax_inclusive IN (0,1)),
    default_payment_terms_days INTEGER NOT NULL DEFAULT 0,
    backup_directory TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY,
    company_id INTEGER,
    name TEXT NOT NULL,
    description TEXT,
    is_system INTEGER NOT NULL DEFAULT 0 CHECK(is_system IN (0,1)),
    UNIQUE(company_id, name),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS permissions (
    id INTEGER PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id INTEGER NOT NULL,
    permission_id INTEGER NOT NULL,
    PRIMARY KEY(role_id, permission_id),
    FOREIGN KEY(role_id) REFERENCES roles(id) ON DELETE CASCADE,
    FOREIGN KEY(permission_id) REFERENCES permissions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    username TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    display_name TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    failed_login_count INTEGER NOT NULL DEFAULT 0,
    locked_until TEXT,
    last_login_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, username),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS user_roles (
    user_id INTEGER NOT NULL,
    role_id INTEGER NOT NULL,
    PRIMARY KEY(user_id, role_id),
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(role_id) REFERENCES roles(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS currencies (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    symbol TEXT,
    decimal_places INTEGER NOT NULL DEFAULT 3 CHECK(decimal_places BETWEEN 0 AND 6),
    exchange_rate_minor INTEGER NOT NULL DEFAULT 1000000,
    is_base INTEGER NOT NULL DEFAULT 0 CHECK(is_base IN (0,1)),
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    UNIQUE(company_id, code),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tax_rates (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    rate_bp INTEGER NOT NULL CHECK(rate_bp >= 0),
    sales_account_id INTEGER,
    purchase_account_id INTEGER,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    UNIQUE(company_id, code),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS financial_years (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','CLOSED')),
    UNIQUE(company_id, name),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    parent_id INTEGER,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    account_type TEXT NOT NULL CHECK(account_type IN ('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE')),
    normal_balance TEXT NOT NULL CHECK(normal_balance IN ('DEBIT','CREDIT')),
    is_control INTEGER NOT NULL DEFAULT 0 CHECK(is_control IN (0,1)),
    is_postable INTEGER NOT NULL DEFAULT 1 CHECK(is_postable IN (0,1)),
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    UNIQUE(company_id, code),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(parent_id) REFERENCES accounts(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS journal_entries (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    financial_year_id INTEGER NOT NULL,
    entry_no INTEGER NOT NULL,
    entry_date TEXT NOT NULL,
    source_type TEXT,
    source_id INTEGER,
    description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'POSTED' CHECK(status IN ('DRAFT','POSTED','REVERSED')),
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, financial_year_id, entry_no),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(financial_year_id) REFERENCES financial_years(id) ON DELETE RESTRICT,
    FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS journal_entry_lines (
    id INTEGER PRIMARY KEY,
    journal_entry_id INTEGER NOT NULL,
    account_id INTEGER NOT NULL,
    line_no INTEGER NOT NULL,
    description TEXT,
    debit_minor INTEGER NOT NULL DEFAULT 0 CHECK(debit_minor >= 0),
    credit_minor INTEGER NOT NULL DEFAULT 0 CHECK(credit_minor >= 0),
    currency_id INTEGER,
    fx_rate_ppm INTEGER,
    FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE,
    FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE RESTRICT,
    CHECK((debit_minor = 0 AND credit_minor > 0) OR (credit_minor = 0 AND debit_minor > 0)),
    UNIQUE(journal_entry_id, line_no)
);

CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    address TEXT,
    credit_limit_minor INTEGER NOT NULL DEFAULT 0,
    receivable_account_id INTEGER,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    UNIQUE(company_id, code),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(receivable_account_id) REFERENCES accounts(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    address TEXT,
    payable_account_id INTEGER,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    UNIQUE(company_id, code),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(payable_account_id) REFERENCES accounts(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS partners (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    ownership_bp INTEGER NOT NULL DEFAULT 0 CHECK(ownership_bp BETWEEN 0 AND 10000),
    capital_account_id INTEGER,
    current_account_id INTEGER,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    UNIQUE(company_id, code),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(capital_account_id) REFERENCES accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(current_account_id) REFERENCES accounts(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS partner_transactions (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    partner_id INTEGER NOT NULL,
    transaction_date TEXT NOT NULL,
    transaction_type TEXT NOT NULL,
    amount_minor INTEGER NOT NULL CHECK(amount_minor > 0),
    description TEXT,
    journal_entry_id INTEGER,
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(partner_id) REFERENCES partners(id) ON DELETE RESTRICT,
    FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    parent_id INTEGER,
    UNIQUE(company_id, name),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(parent_id) REFERENCES categories(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS units (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    UNIQUE(company_id, code),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    sku TEXT NOT NULL,
    barcode TEXT,
    name TEXT NOT NULL,
    category_id INTEGER,
    unit_id INTEGER,
    purchase_price_minor INTEGER NOT NULL DEFAULT 0,
    default_sale_price_minor INTEGER NOT NULL DEFAULT 0,
    min_stock_scaled INTEGER NOT NULL DEFAULT 0,
    max_stock_scaled INTEGER NOT NULL DEFAULT 0,
    inventory_account_id INTEGER,
    sales_account_id INTEGER,
    cogs_account_id INTEGER,
    is_stock_item INTEGER NOT NULL DEFAULT 1 CHECK(is_stock_item IN (0,1)),
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    UNIQUE(company_id, sku),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE RESTRICT,
    FOREIGN KEY(unit_id) REFERENCES units(id) ON DELETE RESTRICT,
    FOREIGN KEY(inventory_account_id) REFERENCES accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(sales_account_id) REFERENCES accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(cogs_account_id) REFERENCES accounts(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS warehouses (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    address TEXT,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    UNIQUE(company_id, code),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS stock_movements (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    warehouse_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    movement_date TEXT NOT NULL,
    movement_type TEXT NOT NULL,
    quantity_scaled INTEGER NOT NULL CHECK(quantity_scaled <> 0),
    unit_cost_minor INTEGER NOT NULL DEFAULT 0,
    source_type TEXT,
    source_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(warehouse_id) REFERENCES warehouses(id) ON DELETE RESTRICT,
    FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS cash_accounts (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    gl_account_id INTEGER NOT NULL,
    currency_id INTEGER,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    UNIQUE(company_id, code),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(gl_account_id) REFERENCES accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(currency_id) REFERENCES currencies(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS bank_accounts (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    bank_name TEXT NOT NULL,
    account_name TEXT,
    account_number TEXT,
    iban TEXT,
    gl_account_id INTEGER NOT NULL,
    currency_id INTEGER,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    UNIQUE(company_id, code),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(gl_account_id) REFERENCES accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(currency_id) REFERENCES currencies(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS sales_invoices (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    customer_id INTEGER,
    warehouse_id INTEGER,
    financial_year_id INTEGER NOT NULL,
    invoice_no INTEGER NOT NULL,
    invoice_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','POSTED','CANCELLED')),
    currency_id INTEGER NOT NULL,
    subtotal_minor INTEGER NOT NULL DEFAULT 0,
    discount_minor INTEGER NOT NULL DEFAULT 0,
    tax_minor INTEGER NOT NULL DEFAULT 0,
    extra_charges_minor INTEGER NOT NULL DEFAULT 0,
    total_minor INTEGER NOT NULL DEFAULT 0,
    paid_minor INTEGER NOT NULL DEFAULT 0,
    notes TEXT,
    journal_entry_id INTEGER,
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, financial_year_id, invoice_no),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE RESTRICT,
    FOREIGN KEY(warehouse_id) REFERENCES warehouses(id) ON DELETE RESTRICT,
    FOREIGN KEY(financial_year_id) REFERENCES financial_years(id) ON DELETE RESTRICT,
    FOREIGN KEY(currency_id) REFERENCES currencies(id) ON DELETE RESTRICT,
    FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE RESTRICT,
    FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS sales_invoice_lines (
    id INTEGER PRIMARY KEY,
    invoice_id INTEGER NOT NULL,
    line_no INTEGER NOT NULL,
    product_id INTEGER,
    description TEXT NOT NULL,
    quantity_scaled INTEGER NOT NULL CHECK(quantity_scaled > 0),
    unit_price_minor INTEGER NOT NULL CHECK(unit_price_minor >= 0),
    discount_minor INTEGER NOT NULL DEFAULT 0 CHECK(discount_minor >= 0),
    tax_rate_id INTEGER,
    tax_minor INTEGER NOT NULL DEFAULT 0,
    line_total_minor INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(invoice_id) REFERENCES sales_invoices(id) ON DELETE CASCADE,
    FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE RESTRICT,
    FOREIGN KEY(tax_rate_id) REFERENCES tax_rates(id) ON DELETE RESTRICT,
    UNIQUE(invoice_id, line_no)
);

CREATE TABLE IF NOT EXISTS purchase_invoices (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    supplier_id INTEGER,
    warehouse_id INTEGER,
    financial_year_id INTEGER NOT NULL,
    invoice_no INTEGER NOT NULL,
    invoice_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','POSTED','CANCELLED')),
    currency_id INTEGER NOT NULL,
    subtotal_minor INTEGER NOT NULL DEFAULT 0,
    discount_minor INTEGER NOT NULL DEFAULT 0,
    tax_minor INTEGER NOT NULL DEFAULT 0,
    extra_charges_minor INTEGER NOT NULL DEFAULT 0,
    total_minor INTEGER NOT NULL DEFAULT 0,
    paid_minor INTEGER NOT NULL DEFAULT 0,
    notes TEXT,
    journal_entry_id INTEGER,
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, financial_year_id, invoice_no),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(supplier_id) REFERENCES suppliers(id) ON DELETE RESTRICT,
    FOREIGN KEY(warehouse_id) REFERENCES warehouses(id) ON DELETE RESTRICT,
    FOREIGN KEY(financial_year_id) REFERENCES financial_years(id) ON DELETE RESTRICT,
    FOREIGN KEY(currency_id) REFERENCES currencies(id) ON DELETE RESTRICT,
    FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE RESTRICT,
    FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS purchase_invoice_lines (
    id INTEGER PRIMARY KEY,
    invoice_id INTEGER NOT NULL,
    line_no INTEGER NOT NULL,
    product_id INTEGER,
    description TEXT NOT NULL,
    quantity_scaled INTEGER NOT NULL CHECK(quantity_scaled > 0),
    unit_price_minor INTEGER NOT NULL CHECK(unit_price_minor >= 0),
    discount_minor INTEGER NOT NULL DEFAULT 0 CHECK(discount_minor >= 0),
    tax_rate_id INTEGER,
    tax_minor INTEGER NOT NULL DEFAULT 0,
    line_total_minor INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(invoice_id) REFERENCES purchase_invoices(id) ON DELETE CASCADE,
    FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE RESTRICT,
    FOREIGN KEY(tax_rate_id) REFERENCES tax_rates(id) ON DELETE RESTRICT,
    UNIQUE(invoice_id, line_no)
);

CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    supplier_id INTEGER,
    cash_account_id INTEGER,
    bank_account_id INTEGER,
    payment_date TEXT NOT NULL,
    amount_minor INTEGER NOT NULL CHECK(amount_minor > 0),
    currency_id INTEGER NOT NULL,
    description TEXT,
    journal_entry_id INTEGER,
    created_by INTEGER NOT NULL,
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(supplier_id) REFERENCES suppliers(id) ON DELETE RESTRICT,
    FOREIGN KEY(cash_account_id) REFERENCES cash_accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(bank_account_id) REFERENCES bank_accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(currency_id) REFERENCES currencies(id) ON DELETE RESTRICT,
    FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE RESTRICT,
    FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE RESTRICT,
    CHECK ((cash_account_id IS NOT NULL) OR (bank_account_id IS NOT NULL))
);

CREATE TABLE IF NOT EXISTS receipts (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    customer_id INTEGER,
    cash_account_id INTEGER,
    bank_account_id INTEGER,
    receipt_date TEXT NOT NULL,
    amount_minor INTEGER NOT NULL CHECK(amount_minor > 0),
    currency_id INTEGER NOT NULL,
    description TEXT,
    journal_entry_id INTEGER,
    created_by INTEGER NOT NULL,
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE RESTRICT,
    FOREIGN KEY(cash_account_id) REFERENCES cash_accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(bank_account_id) REFERENCES bank_accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(currency_id) REFERENCES currencies(id) ON DELETE RESTRICT,
    FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE RESTRICT,
    FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE RESTRICT,
    CHECK ((cash_account_id IS NOT NULL) OR (bank_account_id IS NOT NULL))
);

CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    expense_date TEXT NOT NULL,
    account_id INTEGER NOT NULL,
    amount_minor INTEGER NOT NULL CHECK(amount_minor > 0),
    currency_id INTEGER NOT NULL,
    cash_account_id INTEGER,
    bank_account_id INTEGER,
    description TEXT,
    journal_entry_id INTEGER,
    created_by INTEGER NOT NULL,
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(currency_id) REFERENCES currencies(id) ON DELETE RESTRICT,
    FOREIGN KEY(cash_account_id) REFERENCES cash_accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(bank_account_id) REFERENCES bank_accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE RESTRICT,
    FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE RESTRICT,
    CHECK ((cash_account_id IS NOT NULL) OR (bank_account_id IS NOT NULL))
);

CREATE TABLE IF NOT EXISTS revenues (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    revenue_date TEXT NOT NULL,
    account_id INTEGER NOT NULL,
    amount_minor INTEGER NOT NULL CHECK(amount_minor > 0),
    currency_id INTEGER NOT NULL,
    cash_account_id INTEGER,
    bank_account_id INTEGER,
    description TEXT,
    journal_entry_id INTEGER,
    created_by INTEGER NOT NULL,
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(currency_id) REFERENCES currencies(id) ON DELETE RESTRICT,
    FOREIGN KEY(cash_account_id) REFERENCES cash_accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(bank_account_id) REFERENCES bank_accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE RESTRICT,
    FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE RESTRICT,
    CHECK ((cash_account_id IS NOT NULL) OR (bank_account_id IS NOT NULL))
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY,
    company_id INTEGER,
    user_id INTEGER,
    event_type TEXT NOT NULL,
    entity_type TEXT,
    entity_id INTEGER,
    event_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    old_value TEXT,
    new_value TEXT,
    machine_name TEXT,
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE SET NULL,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS backups (
    id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    backup_path TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    size_bytes INTEGER NOT NULL,
    sha256 TEXT NOT NULL,
    encrypted INTEGER NOT NULL DEFAULT 0 CHECK(encrypted IN (0,1)),
    status TEXT NOT NULL CHECK(status IN ('CREATED','VERIFIED','FAILED','RESTORED')),
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE INDEX IF NOT EXISTS idx_journal_company_date ON journal_entries(company_id, entry_date);
CREATE INDEX IF NOT EXISTS idx_journal_line_account ON journal_entry_lines(account_id);
CREATE INDEX IF NOT EXISTS idx_stock_company_product_date ON stock_movements(company_id, product_id, movement_date);
CREATE INDEX IF NOT EXISTS idx_stock_company_warehouse_product ON stock_movements(company_id, warehouse_id, product_id);
CREATE INDEX IF NOT EXISTS idx_sales_company_date ON sales_invoices(company_id, invoice_date);
CREATE INDEX IF NOT EXISTS idx_purchase_company_date ON purchase_invoices(company_id, invoice_date);
CREATE INDEX IF NOT EXISTS idx_audit_company_time ON audit_logs(company_id, event_time);
CREATE INDEX IF NOT EXISTS idx_customer_code ON customers(company_id, code);
CREATE INDEX IF NOT EXISTS idx_supplier_code ON suppliers(company_id, code);
CREATE INDEX IF NOT EXISTS idx_product_barcode ON products(company_id, barcode);
