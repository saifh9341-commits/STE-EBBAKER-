# FinCore ERP

Foundation for an offline-first Windows desktop accounting/ERP application.

## Target
- Windows 7/8/8.1/10/11 where a compatible Qt 5.12.x toolchain is available.
- C++17.
- Qt 5.12.x Widgets + Qt SQL.
- SQLite database, one database per company in the data directory.

## Phase 1 implemented
- Stable project structure.
- Per-user data directory separated from installation directory.
- SQLite initialization.
- Foreign-key enforcement.
- WAL journaling for normal operation.
- Schema migration table.
- Initial accounting/ERP schema.
- Application logging.
- JSON-like settings via QSettings.
- Basic RTL-ready main window shell.

## Important compatibility note
Qt 5.12.12 was tested/configured with Windows 7 x86 according to Qt's historical configuration documentation. Qt 5.12.12 is archived software, so the production release should be security-audited and its dependency versions frozen before distribution.

## Build
1. Install a Qt 5.12.x kit with MSVC or MinGW compatible with the target Windows versions.
2. Configure with CMake:
   cmake -S . -B build
3. Build:
   cmake --build build --config Release
4. Deploy the Qt runtime and plugins, including the Qt SQL SQLite driver.

The production installer will be added in a later phase.
