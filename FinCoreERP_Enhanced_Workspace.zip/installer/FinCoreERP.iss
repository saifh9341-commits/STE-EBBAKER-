; Inno Setup script for final Windows packaging.
#define MyAppName "FinCore ERP"
#define MyAppVersion "0.1.0"
#define MyAppExeName "FinCoreERP.exe"

[Setup]
AppId={{A9A3F0E1-9A67-4B74-9D5B-0C2D9C9F0001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={autopf}\FinCoreERP
DefaultGroupName={#MyAppName}
OutputBaseFilename=FinCoreERP-Setup-{#MyAppVersion}
Compression=lzma
SolidCompression=yes
PrivilegesRequired=admin

[Files]
Source: "..\build\Release\FinCoreERP.exe"; DestDir: "{app}"; Flags: ignoreversion
; Add Qt DLLs/plugins here from the frozen deployment bundle.

[Icons]
Name: "{group}\FinCore ERP"; Filename: "{app}\FinCoreERP.exe"
Name: "{commondesktop}\FinCore ERP"; Filename: "{app}\FinCoreERP.exe"

[UninstallDelete]
; Intentionally do NOT delete company data.
; Data is outside Program Files.
