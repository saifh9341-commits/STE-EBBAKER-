#include "../src/accounting/AccountingEngine.h"
#include <cassert>
int main(){assert(AccountingEngine::isBalanced({{1,1000,0,"Dr"},{2,0,1000,"Cr"}}));assert(!AccountingEngine::isBalanced({{1,1000,0,"Dr"},{2,0,900,"Cr"}}));}
