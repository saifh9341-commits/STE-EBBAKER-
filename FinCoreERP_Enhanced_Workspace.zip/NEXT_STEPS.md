# FinCore ERP — Current Build State

This revision adds a real first-run flow: local company bootstrap, admin account creation, login dialog, and a database-backed dashboard with live counters.

It is **not yet a production-complete ERP**. Sales, purchasing, accounting, inventory transactions, reports, permissions, backup encryption, printing and installer packaging still require full implementation and Windows target testing.

Default development login on a fresh database: `admin` / `admin123`.

Security note: the current password hasher in this source is PBKDF2-style SHA-512 and is **not Argon2id**. Do not market this revision as security-final.
