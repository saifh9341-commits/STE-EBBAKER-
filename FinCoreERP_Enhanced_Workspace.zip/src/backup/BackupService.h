#pragma once
#include <QString>
#include <QSqlDatabase>
class BackupService { public: static bool create(QSqlDatabase,const QString&,QString*); static bool verify(const QString&,QString*); };
