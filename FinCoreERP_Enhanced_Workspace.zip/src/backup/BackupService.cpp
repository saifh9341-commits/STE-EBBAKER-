#include "BackupService.h"
#include <QFile>
#include <QSqlQuery>
#include <QSqlError>
bool BackupService::create(QSqlDatabase db,const QString& dest,QString* err){
 QSqlQuery q(db);if(!q.exec("PRAGMA wal_checkpoint(FULL)")){if(err)*err=q.lastError().text();return false;}
 QFile in(db.databaseName()),out(dest);if(!in.open(QIODevice::ReadOnly)||!out.open(QIODevice::WriteOnly)){if(err)*err="Cannot open backup files.";return false;}
 while(!in.atEnd())out.write(in.read(1024*1024));out.close();return verify(dest,err);
}
bool BackupService::verify(const QString& f,QString* err){
 QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE","backup_verify");db.setDatabaseName(f);
 if(!db.open()){if(err)*err=db.lastError().text();QSqlDatabase::removeDatabase("backup_verify");return false;}
 QSqlQuery q(db);bool ok=q.exec("PRAGMA integrity_check")&&q.next()&&q.value(0).toString()=="ok";
 if(!ok&&err)*err=q.lastError().text();db.close();QSqlDatabase::removeDatabase("backup_verify");return ok;
}
