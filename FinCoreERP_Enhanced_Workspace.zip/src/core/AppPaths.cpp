#include "AppPaths.h"
#include <QDir>
#include <QStandardPaths>

namespace {
QString appRoot() {
    QString base = QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation);
    if (base.isEmpty())
        base = QDir::homePath() + "/AppData/Roaming";
    return QDir(base).filePath("FinCoreERP");
}
}

namespace AppPaths {
QString rootDataDir() { return appRoot(); }
QString logsDir() { return QDir(appRoot()).filePath("Logs"); }
QString companiesDir() { return QDir(appRoot()).filePath("Companies"); }
QString backupsDir() { return QDir(appRoot()).filePath("Backups"); }
QString companyDir(qint64 companyId) { return QDir(companiesDir()).filePath(QString::number(companyId)); }
QString companyDatabasePath(qint64 companyId) {
    return QDir(companyDir(companyId)).filePath("company.sqlite");
}
QString logFilePath() { return QDir(logsDir()).filePath("application.log"); }

bool ensureDirectories(QString *errorMessage) {
    const QStringList dirs = {rootDataDir(), logsDir(), companiesDir(), backupsDir()};
    for (const QString &path : dirs) {
        if (!QDir().mkpath(path)) {
            if (errorMessage) *errorMessage = "Cannot create data directory: " + path;
            return false;
        }
    }
    return true;
}
}
