#pragma once
#include <QString>
#include <QSqlDatabase>

class Database {
public:
    static Database &instance();

    bool openCompany(qint64 companyId, QString *errorMessage = nullptr);
    void close();

    QSqlDatabase connection() const;
    QString databasePath() const;
    bool isOpen() const;

private:
    Database() = default;
    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;

    bool applyPragmas(QString *errorMessage);
    bool initializeSchema(QString *errorMessage);

    QSqlDatabase m_db;
    QString m_connectionName;
    QString m_path;
};
