#include "Database.h"
#include "AppPaths.h"
#include "Logger.h"
#include <QDir>
#include <QFile>
#include <QSqlError>
#include <QSqlQuery>
#include <QCoreApplication>

Database &Database::instance() {
    static Database db;
    return db;
}

bool Database::openCompany(qint64 companyId, QString *errorMessage) {
    close();

    QString dirError;
    if (!QDir().mkpath(AppPaths::companyDir(companyId))) {
        if (errorMessage) *errorMessage = "Cannot create company data directory.";
        return false;
    }

    m_path = AppPaths::companyDatabasePath(companyId);
    m_connectionName = QString("fincore_company_%1").arg(companyId);

    if (QSqlDatabase::contains(m_connectionName))
        QSqlDatabase::removeDatabase(m_connectionName);

    m_db = QSqlDatabase::addDatabase("QSQLITE", m_connectionName);
    m_db.setDatabaseName(m_path);

    if (!m_db.open()) {
        if (errorMessage) *errorMessage = m_db.lastError().text();
        return false;
    }

    if (!applyPragmas(errorMessage) || !initializeSchema(errorMessage)) {
        close();
        return false;
    }

    Logger::info("Opened company database: " + m_path);
    return true;
}

bool Database::applyPragmas(QString *errorMessage) {
    QSqlQuery q(m_db);
    if (!q.exec("PRAGMA foreign_keys = ON;")) {
        if (errorMessage) *errorMessage = q.lastError().text();
        return false;
    }
    if (!q.exec("PRAGMA journal_mode = WAL;")) {
        if (errorMessage) *errorMessage = q.lastError().text();
        return false;
    }
    if (!q.exec("PRAGMA synchronous = NORMAL;")) {
        if (errorMessage) *errorMessage = q.lastError().text();
        return false;
    }
    if (!q.exec("PRAGMA busy_timeout = 5000;")) {
        if (errorMessage) *errorMessage = q.lastError().text();
        return false;
    }
    return true;
}

bool Database::initializeSchema(QString *errorMessage) {
    QSqlQuery q(m_db);
    if (!q.exec("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);")) {
        if (errorMessage) *errorMessage = q.lastError().text();
        return false;
    }

    if (!q.exec("SELECT COUNT(*) FROM schema_migrations WHERE version = 1;")) {
        if (errorMessage) *errorMessage = q.lastError().text();
        return false;
    }

    if (!q.next()) {
        if (errorMessage) *errorMessage = "Could not read schema migration state.";
        return false;
    }

    if (q.value(0).toInt() == 0) {
        QFile schema(":/schema.sql");
        if (!schema.open(QIODevice::ReadOnly | QIODevice::Text)) {
            if (errorMessage) *errorMessage = "Embedded schema.sql cannot be opened.";
            return false;
        }
        const QString sql = QString::fromUtf8(schema.readAll());

        if (!m_db.transaction()) {
            if (errorMessage) *errorMessage = m_db.lastError().text();
            return false;
        }

        QSqlQuery script(m_db);
        // SQLite accepts multiple statements through sqlite3_exec, but QSqlQuery
        // is intentionally used statement-by-statement. The initial schema is
        // therefore split on semicolons for this bootstrap migration.
        const QStringList statements = sql.split(';', Qt::SkipEmptyParts);
        for (const QString &raw : statements) {
            const QString statement = raw.trimmed();
            if (statement.isEmpty()) continue;
            if (!script.exec(statement)) {
                m_db.rollback();
                if (errorMessage) *errorMessage = script.lastError().text();
                return false;
            }
        }

        if (!script.exec("INSERT INTO schema_migrations(version) VALUES(1);")) {
            m_db.rollback();
            if (errorMessage) *errorMessage = script.lastError().text();
            return false;
        }

        if (!m_db.commit()) {
            if (errorMessage) *errorMessage = m_db.lastError().text();
            return false;
        }
    }

    return true;
}

void Database::close() {
    if (m_db.isValid()) {
        const QString name = m_connectionName;
        m_db.close();
        m_db = QSqlDatabase();
        if (!name.isEmpty())
            QSqlDatabase::removeDatabase(name);
    }
    m_connectionName.clear();
    m_path.clear();
}

QSqlDatabase Database::connection() const { return m_db; }
QString Database::databasePath() const { return m_path; }
bool Database::isOpen() const { return m_db.isOpen(); }
