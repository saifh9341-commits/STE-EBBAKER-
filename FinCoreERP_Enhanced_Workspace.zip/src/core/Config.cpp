#include "Config.h"
#include <QSettings>

static QSettings settings() {
    return QSettings("FinCoreERP", "FinCoreERP");
}

QString Config::language() {
    return settings().value("ui/language", "ar").toString();
}

void Config::setLanguage(const QString &language) {
    QSettings s("FinCoreERP", "FinCoreERP");
    s.setValue("ui/language", language);
}

bool Config::darkMode() {
    return settings().value("ui/darkMode", false).toBool();
}

void Config::setDarkMode(bool enabled) {
    QSettings s("FinCoreERP", "FinCoreERP");
    s.setValue("ui/darkMode", enabled);
}
