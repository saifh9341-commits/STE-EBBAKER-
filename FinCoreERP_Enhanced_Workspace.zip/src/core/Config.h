#pragma once
#include <QString>

class Config {
public:
    static QString language();
    static void setLanguage(const QString &language);
    static bool darkMode();
    static void setDarkMode(bool enabled);
};
