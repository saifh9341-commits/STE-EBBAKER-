#include "Logger.h"
#include "AppPaths.h"
#include <QFile>
#include <QTextStream>
#include <QDateTime>
#include <QMutex>
#include <QMutexLocker>

namespace {
QMutex g_mutex;
}

bool Logger::initialize(QString *errorMessage) {
    return AppPaths::ensureDirectories(errorMessage);
}

void Logger::write(const QString &level, const QString &message) {
    QMutexLocker locker(&g_mutex);
    QFile file(AppPaths::logFilePath());
    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
        return;
    QTextStream out(&file);
    out << QDateTime::currentDateTime().toString(Qt::ISODate)
        << " [" << level << "] " << message << "\n";
}

void Logger::info(const QString &message) { write("INFO", message); }
void Logger::warning(const QString &message) { write("WARN", message); }
void Logger::error(const QString &message) { write("ERROR", message); }
