#pragma once
#include <QString>

namespace AppPaths {
QString rootDataDir();
QString logsDir();
QString companiesDir();
QString backupsDir();
QString companyDir(qint64 companyId);
QString companyDatabasePath(qint64 companyId);
QString logFilePath();
bool ensureDirectories(QString *errorMessage = nullptr);
}
