#pragma once
#include <QString>

class Logger {
public:
    static bool initialize(QString *errorMessage = nullptr);
    static void info(const QString &message);
    static void warning(const QString &message);
    static void error(const QString &message);
private:
    static void write(const QString &level, const QString &message);
};
