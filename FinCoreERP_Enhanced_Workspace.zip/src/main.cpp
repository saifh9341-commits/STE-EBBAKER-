#include <QApplication>
#include <QMessageBox>
#include <QSqlQuery>
#include <QRandomGenerator>
#include "core/Logger.h"
#include "core/Database.h"
#include "security/PasswordHasher.h"
#include "ui/LoginDialog.h"
#include "ui/MainWindow.h"
static bool seedFirstRun(QSqlDatabase db, QString *error){
 QSqlQuery q(db); if(!q.exec("INSERT OR IGNORE INTO companies(id,code,name) VALUES(1,'MAIN','الشركة الرئيسية')")){if(error)*error=q.lastError().text();return false;}
 if(!q.exec("INSERT OR IGNORE INTO company_settings(company_id) VALUES(1)")){if(error)*error=q.lastError().text();return false;}
 if(!q.exec("SELECT COUNT(*) FROM users WHERE company_id=1")){if(error)*error=q.lastError().text();return false;}q.next();if(q.value(0).toInt()==0){QByteArray salt; salt.resize(16);for(int i=0;i<salt.size();++i)salt[i]=char(QRandomGenerator::global()->generate()&0xff);QString hash=PasswordHasher::hashPassword("admin123",salt);q.prepare("INSERT INTO users(company_id,username,password_hash,password_salt,display_name) VALUES(1,?,?,?,?)");q.addBindValue("admin");q.addBindValue(hash);q.addBindValue(salt.toBase64());q.addBindValue("Administrator");if(!q.exec()){if(error)*error=q.lastError().text();return false;}}
 return true;
}
int main(int argc,char *argv[]){QApplication app(argc,argv);QApplication::setApplicationName("FinCoreERP");QApplication::setOrganizationName("FinCoreERP");QApplication::setApplicationVersion(FINCOREERP_VERSION);app.setLayoutDirection(Qt::RightToLeft);QString error;if(!Logger::initialize(&error)){QMessageBox::critical(nullptr,"FinCore ERP",error);return 1;}if(!Database::instance().openCompany(1,&error)){QMessageBox::critical(nullptr,"FinCore ERP",error);return 2;}if(!seedFirstRun(Database::instance().connection(),&error)){QMessageBox::critical(nullptr,"FinCore ERP",error);return 3;}LoginDialog login(Database::instance().connection(),1);if(login.exec()!=QDialog::Accepted){Database::instance().close();return 0;}MainWindow w;w.show();int r=app.exec();Database::instance().close();return r;}
