#pragma once
#include <QSqlDatabase>
#include <QString>
#include <QVector>
struct JournalLine { qint64 accountId=0; qint64 debitMinor=0; qint64 creditMinor=0; QString description; };
class AccountingEngine {
public:
 static bool isBalanced(const QVector<JournalLine>&);
 static bool postJournal(QSqlDatabase,qint64,qint64,const QString&,const QString&,qint64,const QVector<JournalLine>&,qint64*,QString*);
};
