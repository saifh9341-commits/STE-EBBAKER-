#include "AccountingEngine.h"
#include <QSqlQuery>
bool AccountingEngine::isBalanced(const QVector<JournalLine>& ls){
 qint64 d=0,c=0; for(const auto& l:ls){if((l.debitMinor>0&&l.creditMinor>0)||(l.debitMinor==0&&l.creditMinor==0))return false;d+=l.debitMinor;c+=l.creditMinor;} return d==c&&d>0;
}
bool AccountingEngine::postJournal(QSqlDatabase db,qint64 company,qint64 year,const QString& date,const QString& desc,qint64 user,const QVector<JournalLine>& ls,qint64* jid,QString* err){
 if(!isBalanced(ls)){if(err)*err="Journal entry is not balanced.";return false;}
 if(!db.transaction()){if(err)*err=db.lastError().text();return false;}
 QSqlQuery q(db); q.prepare("SELECT COALESCE(MAX(entry_no),0)+1 FROM journal_entries WHERE company_id=? AND financial_year_id=?");
 q.addBindValue(company);q.addBindValue(year);
 if(!q.exec()||!q.next()){db.rollback();if(err)*err=q.lastError().text();return false;}
 qint64 no=q.value(0).toLongLong();
 q.prepare("INSERT INTO journal_entries(company_id,financial_year_id,entry_no,entry_date,description,status,created_by) VALUES(?,?,?,?,?,'POSTED',?)");
 q.addBindValue(company);q.addBindValue(year);q.addBindValue(no);q.addBindValue(date);q.addBindValue(desc);q.addBindValue(user);
 if(!q.exec()){db.rollback();if(err)*err=q.lastError().text();return false;}
 qint64 id=q.lastInsertId().toLongLong();int n=1;
 for(const auto& l:ls){q.prepare("INSERT INTO journal_entry_lines(journal_entry_id,account_id,line_no,description,debit_minor,credit_minor) VALUES(?,?,?,?,?,?)");
  q.addBindValue(id);q.addBindValue(l.accountId);q.addBindValue(n++);q.addBindValue(l.description);q.addBindValue(l.debitMinor);q.addBindValue(l.creditMinor);
  if(!q.exec()){db.rollback();if(err)*err=q.lastError().text();return false;}}
 if(!db.commit()){if(err)*err=db.lastError().text();return false;} if(jid)*jid=id;return true;
}
