#pragma once
#include <QDialog>
#include <QSqlDatabase>
class QLineEdit; class QLabel;
class LoginDialog : public QDialog {
    Q_OBJECT
public:
    explicit LoginDialog(QSqlDatabase db, qint64 companyId, QWidget *parent=nullptr);
    qint64 userId() const { return m_userId; }
    QString displayName() const { return m_displayName; }
private slots:
    void attemptLogin();
private:
    QSqlDatabase m_db; qint64 m_companyId; qint64 m_userId=0; QString m_displayName;
    QLineEdit *m_userEdit=nullptr; QLineEdit *m_passEdit=nullptr; QLabel *m_error=nullptr;
};
