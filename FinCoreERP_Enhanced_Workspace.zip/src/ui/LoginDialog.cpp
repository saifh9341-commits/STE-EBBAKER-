#include "LoginDialog.h"
#include "../security/AuthService.h"
#include <QVBoxLayout><QFormLayout><QLineEdit><QPushButton><QLabel><QDialogButtonBox><QFont>
LoginDialog::LoginDialog(QSqlDatabase db,qint64 companyId,QWidget *parent):QDialog(parent),m_db(db),m_companyId(companyId){
 setWindowTitle(QStringLiteral("FinCore ERP — تسجيل الدخول")); setFixedSize(430,300); setLayoutDirection(Qt::RightToLeft);
 auto *root=new QVBoxLayout(this); auto *title=new QLabel(QStringLiteral("FinCore ERP")); QFont f=title->font();f.setPointSize(22);f.setBold(true);title->setFont(f);title->setAlignment(Qt::AlignCenter);root->addWidget(title);
 auto *form=new QFormLayout; m_userEdit=new QLineEdit; m_passEdit=new QLineEdit; m_passEdit->setEchoMode(QLineEdit::Password); m_userEdit->setPlaceholderText("admin");m_passEdit->setPlaceholderText("كلمة السر");form->addRow(QStringLiteral("اسم المستخدم"),m_userEdit);form->addRow(QStringLiteral("كلمة السر"),m_passEdit);root->addLayout(form);
 m_error=new QLabel; m_error->setWordWrap(true);root->addWidget(m_error); auto *btn=new QPushButton(QStringLiteral("دخول"));btn->setDefault(true);root->addWidget(btn);connect(btn,&QPushButton::clicked,this,&LoginDialog::attemptLogin);connect(m_passEdit,&QLineEdit::returnPressed,this,&LoginDialog::attemptLogin);m_userEdit->setFocus();
}
void LoginDialog::attemptLogin(){auto r=AuthService::login(m_db,m_companyId,m_userEdit->text().trimmed(),m_passEdit->text());if(!r.success){m_error->setText(r.error);m_passEdit->clear();return;}m_userId=r.userId;m_displayName=r.displayName;accept();}
