#include "AuthService.h"
#include "PasswordHasher.h"
#include <QSqlQuery>
#include <QDateTime>
AuthResult AuthService::login(QSqlDatabase db,qint64 companyId,const QString& u,const QString& p){
    AuthResult r; QSqlQuery q(db);
    q.prepare("SELECT id,display_name,password_hash,password_salt,is_active,failed_login_count,locked_until FROM users WHERE company_id=? AND username=?");
    q.addBindValue(companyId); q.addBindValue(u);
    if(!q.exec()||!q.next()){r.error="Invalid username or password.";return r;}
    qint64 id=q.value(0).toLongLong(); QByteArray salt=QByteArray::fromBase64(q.value(3).toByteArray());
    if(!q.value(4).toBool()){r.error="Account is disabled.";return r;}
    QString lock=q.value(6).toString();
    if(!lock.isEmpty() && QDateTime::fromString(lock,Qt::ISODate)>QDateTime::currentDateTime()){r.error="Account temporarily locked.";return r;}
    if(!PasswordHasher::verify(p,q.value(2).toString(),salt)){
        int f=q.value(5).toInt()+1; QSqlQuery u2(db);
        u2.prepare("UPDATE users SET failed_login_count=?,locked_until=? WHERE id=?");
        u2.addBindValue(f); u2.addBindValue(f>=5?QDateTime::currentDateTime().addSecs(300).toString(Qt::ISODate):QString()); u2.addBindValue(id); u2.exec();
        r.error="Invalid username or password."; return r;
    }
    QSqlQuery u2(db); u2.prepare("UPDATE users SET failed_login_count=0,locked_until=NULL,last_login_at=? WHERE id=?");
    u2.addBindValue(QDateTime::currentDateTime().toString(Qt::ISODate));u2.addBindValue(id);u2.exec();
    r.success=true;r.userId=id;r.displayName=q.value(1).toString();return r;
}
