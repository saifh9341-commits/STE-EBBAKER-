#pragma once
#include <QString>
class PasswordHasher {
public:
    static QString hashPassword(const QString &password, const QByteArray &salt);
    static bool verify(const QString &password, const QString &encoded, const QByteArray &salt);
};
