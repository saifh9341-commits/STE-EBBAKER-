#include "PasswordHasher.h"
#include <QCryptographicHash>
QString PasswordHasher::hashPassword(const QString &password,const QByteArray &salt){
    QByteArray d=QCryptographicHash::hash(salt+password.toUtf8(),QCryptographicHash::Sha512);
    for(int i=0;i<120000;++i) d=QCryptographicHash::hash(d+salt+password.toUtf8(),QCryptographicHash::Sha512);
    return QStringLiteral("PBKDF2-SHA512-120000$")+QString::fromLatin1(d.toHex());
}
bool PasswordHasher::verify(const QString &password,const QString &encoded,const QByteArray &salt){
    return hashPassword(password, salt)==encoded;
}
