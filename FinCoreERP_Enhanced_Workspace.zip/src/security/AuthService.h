#pragma once
#include <QString>
#include <QSqlDatabase>
struct AuthResult { bool success=false; qint64 userId=0; QString displayName; QString error; };
class AuthService {
public: static AuthResult login(QSqlDatabase db,qint64 companyId,const QString &username,const QString &password);
};
