@echo off
setlocal
title FinCore ERP - Windows Build
echo ==========================================
echo FinCore ERP - Automatic Build
echo ==========================================
echo.
where cmake >nul 2>nul
if errorlevel 1 (
  echo CMake is not installed or not in PATH.
  echo Install CMake, then run this file again.
  pause
  exit /b 1
)
if "%Qt5_DIR%"=="" (
  echo Qt5_DIR is not configured.
  echo Set Qt5_DIR to your Qt 5.12.x CMake directory, then rerun.
  echo Example:
  echo set Qt5_DIR=C:\Qt\5.12.12\msvc2017_64\lib\cmake\Qt5
  pause
  exit /b 1
)
if not exist build mkdir build
cmake -S . -B build -DCMAKE_PREFIX_PATH="%Qt5_DIR%" -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 goto fail
cmake --build build --config Release
if errorlevel 1 goto fail
echo.
echo BUILD COMPLETED.
echo Run: build\Release\FinCoreERP.exe
pause
exit /b 0
:fail
echo.
echo BUILD FAILED. The most common cause is an incompatible Qt/compiler kit.
pause
exit /b 1
